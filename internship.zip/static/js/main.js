/**
 * StayEase - Modern Hostel Booking & Management System JavaScript
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Auto-dismiss Bootstrap Alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 6000);
    });

    // 2. Booking Live Availability and Pricing Calculator
    const checkInInput = document.getElementById('id_check_in');
    const checkOutInput = document.getElementById('id_check_out');
    const roomIdInput = document.getElementById('room_id_field');

    function calculateBooking() {
        if (!checkInInput || !checkOutInput || !roomIdInput) return;

        const checkIn = checkInInput.value;
        const checkOut = checkOutInput.value;
        const roomId = roomIdInput.value;

        if (!checkIn || !checkOut || !roomId) return;

        const url = `/api/check-availability/?room_id=${roomId}&check_in=${checkIn}&check_out=${checkOut}`;

        fetch(url)
            .then(res => res.json())
            .then(data => {
                const availAlert = document.getElementById('availability-alert');
                const calcSummary = document.getElementById('calc-summary');
                const submitBtn = document.getElementById('submit-booking-btn');

                if (data.success) {
                    if (data.is_available) {
                        availAlert.className = 'alert alert-success d-flex align-items-center mb-3';
                        availAlert.innerHTML = `<i class="bi bi-check-circle-fill fs-5 me-2"></i> <div><strong>Available!</strong> ${data.available_beds} bed(s) available in Room ${data.room_number}.</div>`;
                        availAlert.classList.remove('d-none');
                        if (submitBtn) submitBtn.disabled = false;

                        // Update price breakdown
                        document.getElementById('display-days').innerText = `${data.days} days (${data.months} month/s)`;
                        document.getElementById('display-total').innerText = `₹${data.total_amount.toLocaleString('en-IN')}`;
                        document.getElementById('display-advance').innerText = `₹${data.advance_amount.toLocaleString('en-IN')}`;
                        document.getElementById('display-remaining').innerText = `₹${data.remaining_amount.toLocaleString('en-IN')}`;
                        calcSummary.classList.remove('d-none');
                    } else {
                        availAlert.className = 'alert alert-danger d-flex align-items-center mb-3';
                        availAlert.innerHTML = `<i class="bi bi-exclamation-triangle-fill fs-5 me-2"></i> <div><strong>Fully Booked!</strong> No beds available for these dates. Please select other dates or room.</div>`;
                        availAlert.classList.remove('d-none');
                        if (submitBtn) submitBtn.disabled = true;
                        calcSummary.classList.add('d-none');
                    }
                } else {
                    availAlert.className = 'alert alert-warning mb-3';
                    availAlert.innerText = data.error || 'Could not verify dates.';
                    availAlert.classList.remove('d-none');
                }
            })
            .catch(err => {
                console.error('Availability check failed:', err);
            });
    }

    if (checkInInput && checkOutInput) {
        checkInInput.addEventListener('change', calculateBooking);
        checkOutInput.addEventListener('change', calculateBooking);
        // Initial run
        calculateBooking();
    }

    // 3. Payment Gateway Mode Selector
    const paymentRadios = document.querySelectorAll('input[name="payment_method"]');
    paymentRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            document.querySelectorAll('.payment-section').forEach(el => el.classList.add('d-none'));
            document.querySelectorAll('.payment-method-card').forEach(card => card.classList.remove('selected'));

            this.closest('.payment-method-card').classList.add('selected');
            const targetSection = document.getElementById(`${this.value}-section`);
            if (targetSection) {
                targetSection.classList.remove('d-none');
            }
        });
    });

    // 4. Hostel Gallery Image Thumbnail Switcher
    const mainGalleryImage = document.getElementById('main-gallery-image');
    const thumbnails = document.querySelectorAll('.gallery-thumbnail');

    thumbnails.forEach(thumb => {
        thumb.addEventListener('click', function () {
            if (mainGalleryImage) {
                mainGalleryImage.src = this.dataset.fullUrl || this.src;
                thumbnails.forEach(t => t.classList.remove('border-primary', 'border-3'));
                this.classList.add('border-primary', 'border-3');
            }
        });
    });
});

// Helper for Printing Receipt
function printBookingReceipt() {
    window.print();
}

