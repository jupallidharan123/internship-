from django.contrib import admin
from .models import UserProfile, Facility, Hostel, HostelImage, Room, Booking, Payment, Review


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'user_type', 'phone_number', 'city', 'id_proof_type', 'created_at')
    list_filter = ('user_type', 'city')
    search_fields = ('user__username', 'user__email', 'phone_number', 'city')


class HostelImageInline(admin.TabularInline):
    model = HostelImage
    extra = 2


class RoomInline(admin.TabularInline):
    model = Room
    extra = 2


@admin.register(Facility)
class FacilityAdmin(admin.ModelAdmin):
    list_display = ('name', 'icon_class', 'description')
    search_fields = ('name',)


@admin.register(Hostel)
class HostelAdmin(admin.ModelAdmin):
    list_display = ('name', 'city', 'hostel_type', 'contact_phone', 'is_active', 'created_at')
    list_filter = ('hostel_type', 'city', 'is_active')
    search_fields = ('name', 'city', 'address', 'contact_phone')
    prepopulated_fields = {'slug': ('name',)}
    filter_horizontal = ('facilities',)
    inlines = [HostelImageInline, RoomInline]


@admin.register(Room)
class RoomAdmin(admin.ModelAdmin):
    list_display = ('room_number', 'hostel', 'room_type', 'capacity', 'price_per_month', 'is_ac', 'is_available')
    list_filter = ('room_type', 'is_ac', 'has_attached_washroom', 'is_available', 'hostel')
    search_fields = ('room_number', 'hostel__name')


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('booking_id', 'guest_name', 'room', 'check_in', 'check_out', 'total_amount', 'advance_amount', 'status', 'created_at')
    list_filter = ('status', 'check_in', 'check_out')
    search_fields = ('booking_id', 'guest_name', 'guest_email', 'guest_phone', 'room__room_number', 'room__hostel__name')
    readonly_fields = ('booking_id', 'created_at', 'updated_at')


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('transaction_id', 'booking', 'payment_method', 'amount', 'payment_type', 'status', 'payment_date')
    list_filter = ('payment_method', 'payment_type', 'status')
    search_fields = ('transaction_id', 'booking__booking_id', 'booking__guest_name')
    readonly_fields = ('transaction_id', 'payment_date')


@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('hostel', 'user', 'rating', 'title', 'is_approved', 'created_at')
    list_filter = ('rating', 'is_approved', 'created_at')
    search_fields = ('hostel__name', 'user__username', 'comment')
