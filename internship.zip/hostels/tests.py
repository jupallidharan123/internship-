from datetime import date, timedelta
from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from .models import UserProfile, Facility, Hostel, Room, Booking, Payment, Review


class HostelBookingSystemTests(TestCase):
    def setUp(self):
        self.client = Client()

        # Create Admin
        self.admin_user = User.objects.create_superuser(
            username='admin_test',
            email='admin@test.com',
            password='password123'
        )
        UserProfile.objects.create(
            user=self.admin_user,
            phone_number='1234567890',
            user_type='admin'
        )

        # Create Normal User
        self.resident_user = User.objects.create_user(
            username='resident_test',
            email='resident@test.com',
            password='password123',
            first_name='Test',
            last_name='Resident'
        )
        self.resident_profile = UserProfile.objects.create(
            user=self.resident_user,
            phone_number='9876543210',
            user_type='student',
            city='Bangalore'
        )

        # Create Facility
        self.facility = Facility.objects.create(
            name='High-Speed WiFi',
            icon_class='bi-wifi',
            description='100 Mbps fiber'
        )

        # Create Hostel
        self.hostel = Hostel.objects.create(
            name='Sunflower Boys Hostel',
            hostel_type='boys',
            address='123 College Road',
            city='Bangalore',
            state='Karnataka',
            pincode='560001',
            contact_phone='+91 99999 88888',
            contact_email='sunflower@test.com',
            description='Clean and safe boys hostel'
        )
        self.hostel.facilities.add(self.facility)

        # Create Room with capacity 1 (Single)
        self.single_room = Room.objects.create(
            hostel=self.hostel,
            room_number='101',
            floor=1,
            room_type='single',
            capacity=1,
            total_beds=1,
            price_per_month=10000.00,
            price_per_day=500.00,
            is_ac=True,
            is_available=True
        )

        # Create Room with capacity 2 (Double)
        self.double_room = Room.objects.create(
            hostel=self.hostel,
            room_number='102',
            floor=1,
            room_type='double',
            capacity=2,
            total_beds=2,
            price_per_month=7500.00,
            price_per_day=400.00,
            is_ac=False,
            is_available=True
        )

    def test_homepage_view(self):
        """Test homepage renders successfully with status 200."""
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Sunflower Boys Hostel')

    def test_hostel_search_and_filter(self):
        """Test search filter by city and hostel type."""
        response = self.client.get(reverse('hostel_list') + '?city=Bangalore&type=boys')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Sunflower Boys Hostel')

        # Negative filter test
        response_empty = self.client.get(reverse('hostel_list') + '?city=Mumbai')
        self.assertEqual(response_empty.status_code, 200)
        self.assertNotContains(response_empty, 'Sunflower Boys Hostel')

    def test_double_booking_prevention(self):
        """
        Verify that room availability calculates correctly and prevents double booking.
        Single room (capacity 1) booked from Day 1 to Day 10 should leave 0 beds for overlapping dates.
        """
        today = date.today()
        check_in = today + timedelta(days=1)
        check_out = today + timedelta(days=10)

        # Before booking: 1 bed available
        self.assertEqual(self.single_room.get_available_beds(check_in, check_out), 1)
        self.assertTrue(self.single_room.is_available_for_dates(check_in, check_out))

        # Create confirmed booking
        booking = Booking.objects.create(
            user=self.resident_user,
            room=self.single_room,
            check_in=check_in,
            check_out=check_out,
            duration_days=9,
            total_amount=4500.00,
            advance_amount=1125.00,
            remaining_amount=3375.00,
            status='confirmed',
            guest_name='Test Resident',
            guest_phone='9876543210',
            guest_email='resident@test.com'
        )

        # Check overlapping range (Day 5 to Day 15): Must be 0 beds available!
        overlap_check_in = today + timedelta(days=5)
        overlap_check_out = today + timedelta(days=15)
        self.assertEqual(self.single_room.get_available_beds(overlap_check_in, overlap_check_out), 0)
        self.assertFalse(self.single_room.is_available_for_dates(overlap_check_in, overlap_check_out))

        # Check non-overlapping future range (Day 11 to Day 20): Must be 1 bed available!
        future_check_in = today + timedelta(days=11)
        future_check_out = today + timedelta(days=20)
        self.assertEqual(self.single_room.get_available_beds(future_check_in, future_check_out), 1)
        self.assertTrue(self.single_room.is_available_for_dates(future_check_in, future_check_out))

    def test_payment_and_booking_receipt(self):
        """Test payment gateway simulation and booking confirmation."""
        today = date.today()
        booking = Booking.objects.create(
            user=self.resident_user,
            room=self.double_room,
            check_in=today + timedelta(days=2),
            check_out=today + timedelta(days=32),
            total_amount=7500.00,
            advance_amount=1875.00,
            remaining_amount=5625.00,
            status='pending',
            guest_name='Test Resident',
            guest_phone='9876543210',
            guest_email='resident@test.com'
        )

        self.client.login(username='resident_test', password='password123')

        # Simulate Payment
        response = self.client.post(
            reverse('payment_gateway', args=[booking.booking_id]),
            {
                'payment_method': 'upi',
                'simulation_status': 'success',
                'upi_id': 'test@upi'
            }
        )
        self.assertEqual(response.status_code, 302)

        # Verify booking updated to confirmed
        booking.refresh_from_db()
        self.assertEqual(booking.status, 'confirmed')
        self.assertTrue(booking.payments.filter(status='success').exists())

        # Verify receipt page renders
        receipt_response = self.client.get(reverse('booking_receipt', args=[booking.booking_id]))
        self.assertEqual(receipt_response.status_code, 200)
        self.assertContains(receipt_response, booking.booking_id)

    def test_admin_access_control(self):
        """Test that regular users cannot access the admin dashboard, but admins can."""
        # Non-logged in
        response = self.client.get(reverse('admin_dashboard'))
        self.assertEqual(response.status_code, 302)

        # Logged in as student
        self.client.login(username='resident_test', password='password123')
        response_student = self.client.get(reverse('admin_dashboard'))
        self.assertEqual(response_student.status_code, 302)

        # Logged in as admin
        self.client.login(username='admin_test', password='password123')
        response_admin = self.client.get(reverse('admin_dashboard'))
        self.assertEqual(response_admin.status_code, 200)
        self.assertContains(response_admin, 'Hostel Operations Dashboard')
