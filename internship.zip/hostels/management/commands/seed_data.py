import random
from datetime import date, timedelta
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from hostels.models import UserProfile, Facility, Hostel, HostelImage, Room, Booking, Payment, Review


class Command(BaseCommand):
    help = 'Seeds database with realistic sample hostels, rooms, facilities, users, bookings, and reviews.'

    def handle(self, *args, **kwargs):
        self.stdout.write("Starting database seeding...")

        # 1. Create or get Admin Superuser
        admin_user, created = User.objects.get_or_create(
            username='admin',
            defaults={
                'email': 'admin@stayease.com',
                'first_name': 'Super',
                'last_name': 'Admin',
                'is_staff': True,
                'is_superuser': True,
            }
        )
        if created:
            admin_user.set_password('admin123')
            admin_user.save()
            UserProfile.objects.create(
                user=admin_user,
                phone_number='+91 98765 43210',
                user_type='admin',
                city='Bangalore',
                address='StayEase Central Office, Indiranagar, Bangalore'
            )
            self.stdout.write(self.style.SUCCESS("Created Superuser: admin / admin123"))

        # 2. Create Sample Normal Users
        sample_users = [
            {
                'username': 'rahul',
                'password': 'user123',
                'first_name': 'Rahul',
                'last_name': 'Sharma',
                'email': 'rahul.sharma@example.com',
                'phone': '+91 91234 56789',
                'type': 'student',
                'city': 'Bangalore',
                'address': 'Flat 204, Green Glen Layout, Bellandur, Bangalore',
                'avatar': 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=300&q=80',
            },
            {
                'username': 'priya',
                'password': 'user123',
                'first_name': 'Priya',
                'last_name': 'Patel',
                'email': 'priya.patel@example.com',
                'phone': '+91 98220 12345',
                'type': 'professional',
                'city': 'Pune',
                'address': 'Row House 12, Nyati Estate, Viman Nagar, Pune',
                'avatar': 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
            },
            {
                'username': 'ananya',
                'password': 'user123',
                'first_name': 'Ananya',
                'last_name': 'Verma',
                'email': 'ananya.v@example.com',
                'phone': '+91 97110 98765',
                'type': 'student',
                'city': 'Hyderabad',
                'address': 'Plot 45, Silicon Valley Colony, Madhapur, Hyderabad',
                'avatar': 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
            }
        ]

        created_users = [admin_user]
        for udata in sample_users:
            u, u_created = User.objects.get_or_create(
                username=udata['username'],
                defaults={
                    'first_name': udata['first_name'],
                    'last_name': udata['last_name'],
                    'email': udata['email'],
                }
            )
            if u_created:
                u.set_password(udata['password'])
                u.save()
                UserProfile.objects.create(
                    user=u,
                    phone_number=udata['phone'],
                    user_type=udata['type'],
                    city=udata['city'],
                    address=udata['address'],
                    profile_image=udata['avatar'],
                    id_proof_type='aadhar',
                    id_proof_number='XXXX-XXXX-4589',
                    emergency_contact='+91 99887 76655'
                )
                self.stdout.write(self.style.SUCCESS(f"Created User: {udata['username']} / {udata['password']}"))
            created_users.append(u)

        # 3. Create Facilities
        facilities_data = [
            {'name': 'High-Speed WiFi', 'icon_class': 'bi-wifi', 'description': '100+ Mbps fiber internet across all rooms & common areas'},
            {'name': 'Air Conditioning', 'icon_class': 'bi-snow', 'description': 'Inverter ACs in designated rooms with individual remote controls'},
            {'name': 'Delicious Meals & Mess', 'icon_class': 'bi-cup-hot', 'description': 'Hygienic, 3-time hot buffet meals (breakfast, lunch, dinner)'},
            {'name': '24/7 Power Backup', 'icon_class': 'bi-lightning-charge', 'description': 'Full generator backup for lights, fans, WiFi & plugs'},
            {'name': 'CCTV & Biometric Security', 'icon_class': 'bi-shield-check', 'description': 'Round-the-clock security guard, biometric door access & CCTV'},
            {'name': 'RO Purified Water', 'icon_class': 'bi-droplet', 'description': 'Multistage RO + UV mineral water dispensers on each floor'},
            {'name': 'Laundry & Washing Machine', 'icon_class': 'bi-water', 'description': 'Fully automatic washing machines with drying area'},
            {'name': 'Gym & Fitness Space', 'icon_class': 'bi-bicycle', 'description': 'Basic gym equipment, dumbbells, yoga mats, and treadmills'},
            {'name': 'Quiet Study Lounge', 'icon_class': 'bi-book', 'description': 'Air-conditioned study desks with ergonomic chairs & power sockets'},
            {'name': 'Daily Housekeeping', 'icon_class': 'bi-stars', 'description': 'Daily room dusting, floor mopping, and bathroom sanitization'},
            {'name': 'Refrigerator & Microwave', 'icon_class': 'bi-box-seam', 'description': 'Common pantry equipped with microwave, fridge & kettle'},
            {'name': 'Spacious Parking', 'icon_class': 'bi-p-circle', 'description': 'Covered two-wheeler & four-wheeler secure parking area'},
        ]

        facility_objs = {}
        for f in facilities_data:
            obj, _ = Facility.objects.get_or_create(
                name=f['name'],
                defaults={'icon_class': f['icon_class'], 'description': f['description']}
            )
            facility_objs[f['name']] = obj

        # 4. Create Hostels
        hostels_data = [
            {
                'name': 'Greenview Premium Boys Hostel',
                'hostel_type': 'boys',
                'address': '84, 5th Block, Near Jyoti Nivas College Road, Koramangala',
                'city': 'Bangalore',
                'state': 'Karnataka',
                'pincode': '560095',
                'landmark': 'Behind Sony World Signal',
                'contact_phone': '+91 80 4123 4567',
                'contact_email': 'greenview.blr@stayease.com',
                'warden_name': 'Mr. Suresh Nair',
                'description': 'Greenview Premium is a top-rated boys hostel located in the heart of Koramangala. Ideal for IT professionals and college students with high-speed fiber internet, chef-prepared north/south Indian food, clean rooms, and 24/7 security.',
                'rules': 'Gate closes at 11:00 PM. No smoking or alcohol allowed on premises. Overnight guests must be registered at the reception.',
                'image': 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1200&q=80',
                'facilities': ['High-Speed WiFi', 'Delicious Meals & Mess', '24/7 Power Backup', 'CCTV & Biometric Security', 'RO Purified Water', 'Daily Housekeeping', 'Laundry & Washing Machine'],
                'rooms': [
                    {'num': '101', 'floor': 1, 'type': 'single', 'cap': 1, 'price': 13500, 'daily': 700, 'ac': True, 'wash': True, 'bal': True, 'img': 'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80'},
                    {'num': '102', 'floor': 1, 'type': 'double', 'cap': 2, 'price': 9000, 'daily': 500, 'ac': True, 'wash': True, 'bal': False, 'img': 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80'},
                    {'num': '201', 'floor': 2, 'type': 'double', 'cap': 2, 'price': 7500, 'daily': 400, 'ac': False, 'wash': True, 'bal': True, 'img': 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=800&q=80'},
                    {'num': '202', 'floor': 2, 'type': 'triple', 'cap': 3, 'price': 6000, 'daily': 350, 'ac': False, 'wash': True, 'bal': False, 'img': 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80'},
                ]
            },
            {
                'name': 'Lotus Bloom Luxury Girls PG & Hostel',
                'hostel_type': 'girls',
                'address': 'Plot 28, Lane 4, Near Symbiosis International School, Viman Nagar',
                'city': 'Pune',
                'state': 'Maharashtra',
                'pincode': '411014',
                'landmark': 'Opposite Phoenix Marketcity Mall',
                'contact_phone': '+91 20 2663 8899',
                'contact_email': 'lotusbloom.pune@stayease.com',
                'warden_name': 'Mrs. Meenakshi Joshi',
                'description': 'Lotus Bloom is an exclusive, highly secure girls hostel designed with modern aesthetics. Features biometric access, CCTV monitoring on every floor, fully equipped gym, healthy buffet food, and a vibrant community atmosphere.',
                'rules': 'Entry allowed till 10:30 PM. Late pass can be requested via student portal. Male visitors only allowed in ground floor visitors lounge.',
                'image': 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=1200&q=80',
                'facilities': ['High-Speed WiFi', 'Air Conditioning', 'Delicious Meals & Mess', 'CCTV & Biometric Security', 'RO Purified Water', 'Gym & Fitness Space', 'Quiet Study Lounge', 'Daily Housekeeping'],
                'rooms': [
                    {'num': 'G-1', 'floor': 1, 'type': 'single', 'cap': 1, 'price': 14000, 'daily': 750, 'ac': True, 'wash': True, 'bal': True, 'img': 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80'},
                    {'num': 'G-2', 'floor': 1, 'type': 'double', 'cap': 2, 'price': 9500, 'daily': 500, 'ac': True, 'wash': True, 'bal': True, 'img': 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80'},
                    {'num': 'G-3', 'floor': 2, 'type': 'triple', 'cap': 3, 'price': 7000, 'daily': 400, 'ac': True, 'wash': True, 'bal': False, 'img': 'https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=800&q=80'},
                ]
            },
            {
                'name': 'UrbanNest Co-Living Spaces',
                'hostel_type': 'coliving',
                'address': 'Building 14, Hitec City Main Road, Madhapur',
                'city': 'Hyderabad',
                'state': 'Telangana',
                'pincode': '500081',
                'landmark': 'Next to Mindspace IT Park & Cyber Towers',
                'contact_phone': '+91 40 4455 6677',
                'contact_email': 'urbannest.hyd@stayease.com',
                'warden_name': 'Mr. Vikram Reddy',
                'description': 'UrbanNest offers flexible, community-first co-living spaces for working professionals and tech enthusiasts. Enjoy rooftop cafe, weekly events, co-working tables, gaming zone, and hassle-free housekeeping.',
                'rules': '24/7 keycard entry available. Respect community quiet hours after 11 PM. Clean up common kitchen after personal use.',
                'image': 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1200&q=80',
                'facilities': ['High-Speed WiFi', 'Air Conditioning', 'Delicious Meals & Mess', '24/7 Power Backup', 'CCTV & Biometric Security', 'Gym & Fitness Space', 'Quiet Study Lounge', 'Spacious Parking'],
                'rooms': [
                    {'num': 'U-101', 'floor': 1, 'type': 'single', 'cap': 1, 'price': 16000, 'daily': 850, 'ac': True, 'wash': True, 'bal': True, 'img': 'https://images.unsplash.com/photo-1616594039964-ae9021a400a0?auto=format&fit=crop&w=800&q=80'},
                    {'num': 'U-102', 'floor': 1, 'type': 'double', 'cap': 2, 'price': 10500, 'daily': 600, 'ac': True, 'wash': True, 'bal': True, 'img': 'https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=800&q=80'},
                    {'num': 'U-201', 'floor': 2, 'type': 'four', 'cap': 4, 'price': 6500, 'daily': 350, 'ac': True, 'wash': True, 'bal': False, 'img': 'https://images.unsplash.com/photo-1540518614846-7ede433c4ef4?auto=format&fit=crop&w=800&q=80'},
                ]
            },
            {
                'name': 'Heritage Scholar Boys Residency',
                'hostel_type': 'boys',
                'address': 'C-42, Sector 62, Near Gautam Buddha University Extension',
                'city': 'Delhi NCR',
                'state': 'Uttar Pradesh',
                'pincode': '201309',
                'landmark': '500m from Electronic City Metro Station',
                'contact_phone': '+91 120 4567 890',
                'contact_email': 'heritage.noida@stayease.com',
                'warden_name': 'Col. R. K. Sharma (Retd.)',
                'description': 'Designed specifically for students preparing for competitive exams and engineering programs. Offers strict discipline, distraction-free air conditioned study halls, library facilities, and wholesome nutritional food.',
                'rules': 'Curfew time: 10:00 PM. High noise is prohibited at all times in corridors. Parents can stay in guest rooms with prior intimation.',
                'image': 'https://images.unsplash.com/photo-1541123437800-1bb1317badc2?auto=format&fit=crop&w=1200&q=80',
                'facilities': ['High-Speed WiFi', 'Air Conditioning', 'Delicious Meals & Mess', '24/7 Power Backup', 'RO Purified Water', 'Quiet Study Lounge', 'Daily Housekeeping'],
                'rooms': [
                    {'num': 'H-101', 'floor': 1, 'type': 'single', 'cap': 1, 'price': 11000, 'daily': 600, 'ac': True, 'wash': True, 'bal': False, 'img': 'https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=800&q=80'},
                    {'num': 'H-102', 'floor': 1, 'type': 'double', 'cap': 2, 'price': 8000, 'daily': 450, 'ac': True, 'wash': True, 'bal': True, 'img': 'https://images.unsplash.com/photo-1591088398332-8a7791972843?auto=format&fit=crop&w=800&q=80'},
                    {'num': 'H-201', 'floor': 2, 'type': 'triple', 'cap': 3, 'price': 5500, 'daily': 300, 'ac': False, 'wash': True, 'bal': False, 'img': 'https://images.unsplash.com/photo-1560185007-cde436f6a4d0?auto=format&fit=crop&w=800&q=80'},
                ]
            },
            {
                'name': 'Seaside Palms Executive Girls Stay',
                'hostel_type': 'girls',
                'address': '12/A, Rajiv Gandhi Salai (OMR), Perungudi',
                'city': 'Chennai',
                'state': 'Tamil Nadu',
                'pincode': '600096',
                'landmark': 'Near SP Infocity & RMZ Millenia IT Park',
                'contact_phone': '+91 44 2496 1122',
                'contact_email': 'seaside.chn@stayease.com',
                'warden_name': 'Ms. Revathi Sundaram',
                'description': 'Enjoy coastal breeze and premium hostel living on OMR. Ideal for women working in Tidel Park and OMR IT corridor. Includes delicious authentic South & North Indian food options, round the clock security, and high speed WiFi.',
                'rules': 'Biometric login required at entry. Gate timing is 10:30 PM. Visitors allowed in reception lounge between 4 PM and 8 PM.',
                'image': 'https://images.unsplash.com/photo-1502005229762-ee1b2b8ab98f?auto=format&fit=crop&w=1200&q=80',
                'facilities': ['High-Speed WiFi', 'Air Conditioning', 'Delicious Meals & Mess', 'CCTV & Biometric Security', 'RO Purified Water', 'Laundry & Washing Machine', 'Daily Housekeeping'],
                'rooms': [
                    {'num': 'SP-101', 'floor': 1, 'type': 'single', 'cap': 1, 'price': 13000, 'daily': 700, 'ac': True, 'wash': True, 'bal': True, 'img': 'https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=800&q=80'},
                    {'num': 'SP-102', 'floor': 1, 'type': 'double', 'cap': 2, 'price': 8800, 'daily': 480, 'ac': True, 'wash': True, 'bal': False, 'img': 'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=800&q=80'},
                    {'num': 'SP-201', 'floor': 2, 'type': 'triple', 'cap': 3, 'price': 6200, 'daily': 350, 'ac': False, 'wash': True, 'bal': True, 'img': 'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80'},
                ]
            },
            {
                'name': 'Silicon Oasis Modern Co-Living',
                'hostel_type': 'coliving',
                'address': 'Tower B, ITPL Main Road, Whitefield',
                'city': 'Bangalore',
                'state': 'Karnataka',
                'pincode': '560066',
                'landmark': '5 mins from Hopefarm Junction Metro',
                'contact_phone': '+91 80 6789 0123',
                'contact_email': 'siliconoasis.blr@stayease.com',
                'warden_name': 'Mr. Sandeep Patil',
                'description': 'Silicon Oasis is a sleek, hotel-grade co-living residence in Whitefield. Features dedicated workstations, high-speed dual WiFi, terrace barbeque deck, regular housekeeping, and delicious meals.',
                'rules': 'No noise after 11 PM. Keep keycards safe at all times. Alcohol not allowed in common hallways.',
                'image': 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&w=1200&q=80',
                'facilities': ['High-Speed WiFi', 'Air Conditioning', 'Delicious Meals & Mess', '24/7 Power Backup', 'CCTV & Biometric Security', 'Gym & Fitness Space', 'Spacious Parking', 'Daily Housekeeping'],
                'rooms': [
                    {'num': 'SO-101', 'floor': 1, 'type': 'single', 'cap': 1, 'price': 15500, 'daily': 800, 'ac': True, 'wash': True, 'bal': True, 'img': 'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80'},
                    {'num': 'SO-102', 'floor': 1, 'type': 'double', 'cap': 2, 'price': 9800, 'daily': 520, 'ac': True, 'wash': True, 'bal': True, 'img': 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=800&q=80'},
                    {'num': 'SO-201', 'floor': 2, 'type': 'double', 'cap': 2, 'price': 8500, 'daily': 450, 'ac': False, 'wash': True, 'bal': False, 'img': 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80'},
                ]
            }
        ]

        all_rooms = []
        for hdata in hostels_data:
            hostel, h_created = Hostel.objects.get_or_create(
                name=hdata['name'],
                defaults={
                    'hostel_type': hdata['hostel_type'],
                    'address': hdata['address'],
                    'city': hdata['city'],
                    'state': hdata['state'],
                    'pincode': hdata['pincode'],
                    'landmark': hdata['landmark'],
                    'contact_phone': hdata['contact_phone'],
                    'contact_email': hdata['contact_email'],
                    'warden_name': hdata['warden_name'],
                    'description': hdata['description'],
                    'rules_and_regulations': hdata['rules'],
                    'featured_image': hdata['image'],
                    'total_floors': 3,
                    'is_active': True,
                }
            )

            # Associate Facilities
            for fname in hdata['facilities']:
                if fname in facility_objs:
                    hostel.facilities.add(facility_objs[fname])

            # Add Gallery Images
            gallery_urls = [
                'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=800&q=80',
                'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80',
                'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
            ]
            for g_url in gallery_urls:
                HostelImage.objects.get_or_create(
                    hostel=hostel,
                    image_url=g_url,
                    defaults={'caption': f"Interior view of {hostel.name}"}
                )

            # Add Rooms
            for rdata in hdata['rooms']:
                room, _ = Room.objects.get_or_create(
                    hostel=hostel,
                    room_number=rdata['num'],
                    defaults={
                        'floor': rdata['floor'],
                        'room_type': rdata['type'],
                        'capacity': rdata['cap'],
                        'total_beds': rdata['cap'],
                        'price_per_month': rdata['price'],
                        'price_per_day': rdata['daily'],
                        'is_ac': rdata['ac'],
                        'has_attached_washroom': rdata['wash'],
                        'has_balcony': rdata['bal'],
                        'description': f"Spacious {rdata['type'].title()} room with modern wardrobe, study table, and ergonomic chair.",
                        'image_url': rdata['img'],
                        'is_available': True,
                    }
                )
                all_rooms.append(room)

            self.stdout.write(self.style.SUCCESS(f"Configured Hostel: {hostel.name} ({hostel.city})"))

        # 5. Create Sample Bookings and Payments
        today = date.today()
        user_rahul = User.objects.get(username='rahul')
        user_priya = User.objects.get(username='priya')
        user_ananya = User.objects.get(username='ananya')

        if all_rooms:
            # Booking 1: Rahul in Room 102
            b1, b1_created = Booking.objects.get_or_create(
                user=user_rahul,
                room=all_rooms[1],
                check_in=today - timedelta(days=10),
                defaults={
                    'check_out': today + timedelta(days=50),
                    'duration_days': 60,
                    'total_amount': 18000.00,
                    'advance_amount': 4500.00,
                    'remaining_amount': 13500.00,
                    'status': 'confirmed',
                    'guest_name': 'Rahul Sharma',
                    'guest_phone': '+91 91234 56789',
                    'guest_email': 'rahul.sharma@example.com',
                    'emergency_contact': '+91 99887 76655',
                    'special_requests': 'Quiet study corner preferred on upper floor.'
                }
            )
            if b1_created:
                Payment.objects.create(
                    booking=b1,
                    transaction_id=f"PAY-{random.randint(100000, 999999)}",
                    payment_method='upi',
                    payment_type='advance',
                    amount=4500.00,
                    status='success',
                    upi_id='rahul@okhdfcbank',
                    remarks='Advance deposit confirmed'
                )

            # Booking 2: Priya in Lotus Bloom
            if len(all_rooms) > 4:
                b2, b2_created = Booking.objects.get_or_create(
                    user=user_priya,
                    room=all_rooms[4],
                    check_in=today - timedelta(days=5),
                    defaults={
                        'check_out': today + timedelta(days=25),
                        'duration_days': 30,
                        'total_amount': 9500.00,
                        'advance_amount': 9500.00,
                        'remaining_amount': 0.00,
                        'status': 'confirmed',
                        'guest_name': 'Priya Patel',
                        'guest_phone': '+91 98220 12345',
                        'guest_email': 'priya.patel@example.com',
                        'emergency_contact': '+91 94220 54321',
                        'special_requests': 'Near WiFi router if possible.'
                    }
                )
                if b2_created:
                    Payment.objects.create(
                        booking=b2,
                        transaction_id=f"PAY-{random.randint(100000, 999999)}",
                        payment_method='card',
                        payment_type='full',
                        amount=9500.00,
                        status='success',
                        card_last4='4242',
                        bank_name='HDFC Bank',
                        remarks='Full 100% stay fee'
                    )

            # Booking 3: Ananya in UrbanNest (Upcoming)
            if len(all_rooms) > 7:
                b3, b3_created = Booking.objects.get_or_create(
                    user=user_ananya,
                    room=all_rooms[7],
                    check_in=today + timedelta(days=3),
                    defaults={
                        'check_out': today + timedelta(days=33),
                        'duration_days': 30,
                        'total_amount': 10500.00,
                        'advance_amount': 2625.00,
                        'remaining_amount': 7875.00,
                        'status': 'confirmed',
                        'guest_name': 'Ananya Verma',
                        'guest_phone': '+91 97110 98765',
                        'guest_email': 'ananya.v@example.com',
                        'emergency_contact': '+91 98111 22334',
                        'special_requests': 'Vegetarian food preference.'
                    }
                )
                if b3_created:
                    Payment.objects.create(
                        booking=b3,
                        transaction_id=f"PAY-{random.randint(100000, 999999)}",
                        payment_method='upi',
                        payment_type='advance',
                        amount=2625.00,
                        status='success',
                        upi_id='ananya@icici',
                        remarks='25% advance slot reservation'
                    )

        # 6. Create Reviews
        reviews_data = [
            {
                'hostel_idx': 0,
                'user': user_rahul,
                'rating': 5,
                'title': 'Outstanding food, zero WiFi drops!',
                'comment': 'Living here for 3 months now. Food quality is far better than normal PGs, hot water is available 24/7, and the warden Mr. Suresh is genuinely helpful. Highly recommended for students and tech professionals in Koramangala!'
            },
            {
                'hostel_idx': 1,
                'user': user_priya,
                'rating': 5,
                'title': 'Safe, spotless, and right next to Phoenix Mall!',
                'comment': 'Security at Lotus Bloom is phenomenal. Biometric entry gives complete peace of mind. Daily housekeeping ensures rooms and bathrooms are spotless. Great community of girls!'
            },
            {
                'hostel_idx': 2,
                'user': user_ananya,
                'rating': 4,
                'title': 'Vibrant co-living atmosphere in Hitec City',
                'comment': 'Awesome terrace lounge and lightning-fast internet. Walking distance to Mindspace IT Park. Price is slightly on the higher side but the amenities and cleanliness make it worth every penny.'
            }
        ]

        hostels_list = list(Hostel.objects.all())
        for rdata in reviews_data:
            if rdata['hostel_idx'] < len(hostels_list):
                h = hostels_list[rdata['hostel_idx']]
                Review.objects.get_or_create(
                    hostel=h,
                    user=rdata['user'],
                    defaults={
                        'rating': rdata['rating'],
                        'title': rdata['title'],
                        'comment': rdata['comment'],
                        'is_approved': True,
                    }
                )

        self.stdout.write(self.style.SUCCESS("\n========================================================"))
        self.stdout.write(self.style.SUCCESS("Database Seeding Completed Successfully!"))
        self.stdout.write(self.style.SUCCESS("Sample Credentials:"))
        self.stdout.write("  Admin Portal:      admin / admin123")
        self.stdout.write("  Student Account:   rahul / user123")
        self.stdout.write("  Prof. Account:     priya / user123")
        self.stdout.write("  Resident Account:  ananya / user123")
        self.stdout.write(self.style.SUCCESS("========================================================\n"))

