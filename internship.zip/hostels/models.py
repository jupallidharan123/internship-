import uuid
from datetime import date
from django.db import models
from django.contrib.auth.models import User
from django.utils.text import slugify
from django.db.models import Avg, Sum, Q


class UserProfile(models.Model):
    USER_TYPE_CHOICES = (
        ('student', 'Student'),
        ('professional', 'Working Professional'),
        ('admin', 'Hostel Admin / Warden'),
    )
    ID_PROOF_CHOICES = (
        ('aadhar', 'Aadhar Card'),
        ('college_id', 'College / Student ID'),
        ('work_id', 'Employee / Work ID'),
        ('passport', 'Passport'),
        ('voter_id', 'Voter ID'),
    )

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    phone_number = models.CharField(max_length=20, blank=True)
    user_type = models.CharField(max_length=20, choices=USER_TYPE_CHOICES, default='student')
    address = models.TextField(blank=True)
    city = models.CharField(max_length=100, blank=True)
    emergency_contact = models.CharField(max_length=20, blank=True)
    id_proof_type = models.CharField(max_length=20, choices=ID_PROOF_CHOICES, default='aadhar', blank=True)
    id_proof_number = models.CharField(max_length=50, blank=True)
    profile_image = models.CharField(
        max_length=500,
        blank=True,
        default='https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} ({self.get_user_type_display()})"


class Facility(models.Model):
    name = models.CharField(max_length=100, unique=True)
    icon_class = models.CharField(
        max_length=50,
        default='bi-check-circle',
        help_text="Bootstrap icon class, e.g., 'bi-wifi', 'bi-snow', 'bi-cup-hot'"
    )
    description = models.TextField(blank=True)

    class Meta:
        verbose_name_plural = "Facilities"
        ordering = ['name']

    def __str__(self):
        return self.name


class Hostel(models.Model):
    HOSTEL_TYPE_CHOICES = (
        ('boys', "Boys' Hostel"),
        ('girls', "Girls' Hostel"),
        ('coliving', "Co-living Hostel"),
    )

    name = models.CharField(max_length=200)
    slug = models.SlugField(max_length=250, unique=True, blank=True)
    hostel_type = models.CharField(max_length=20, choices=HOSTEL_TYPE_CHOICES, default='coliving')
    address = models.TextField()
    city = models.CharField(max_length=100, db_index=True)
    state = models.CharField(max_length=100)
    pincode = models.CharField(max_length=10)
    landmark = models.CharField(max_length=200, blank=True)
    contact_phone = models.CharField(max_length=20)
    contact_email = models.EmailField()
    warden_name = models.CharField(max_length=100, blank=True)
    description = models.TextField()
    rules_and_regulations = models.TextField(
        help_text="Hostel rules, gate timings, visitor policies, etc.",
        blank=True
    )
    featured_image = models.CharField(
        max_length=500,
        default='https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1200&q=80'
    )
    facilities = models.ManyToManyField(Facility, related_name='hostels', blank=True)
    total_floors = models.PositiveIntegerField(default=3)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(f"{self.name}-{self.city}")
            slug = base_slug
            counter = 1
            while Hostel.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1
            self.slug = slug
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.name} - {self.city} ({self.get_hostel_type_display()})"

    @property
    def average_rating(self):
        avg = self.reviews.aggregate(avg_score=Avg('rating'))['avg_score']
        return round(avg, 1) if avg else 4.5

    @property
    def total_reviews(self):
        return self.reviews.count()

    @property
    def min_price(self):
        lowest = self.rooms.filter(is_available=True).order_by('price_per_month').first()
        return lowest.price_per_month if lowest else 0

    @property
    def total_rooms_count(self):
        return self.rooms.count()

    @property
    def total_beds_count(self):
        total = self.rooms.aggregate(total=Sum('total_beds'))['total']
        return total if total else 0

    @property
    def available_beds_count(self):
        total_avail = 0
        for room in self.rooms.filter(is_available=True):
            total_avail += room.get_available_beds()
        return total_avail


class HostelImage(models.Model):
    hostel = models.ForeignKey(Hostel, on_delete=models.CASCADE, related_name='gallery_images')
    image_url = models.CharField(max_length=500)
    caption = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image for {self.hostel.name} ({self.caption or 'Photo'})"


class Room(models.Model):
    ROOM_TYPE_CHOICES = (
        ('single', 'Single Private Room'),
        ('double', '2-Sharing Room'),
        ('triple', '3-Sharing Room'),
        ('four', '4-Sharing Dormitory'),
    )

    hostel = models.ForeignKey(Hostel, on_delete=models.CASCADE, related_name='rooms')
    room_number = models.CharField(max_length=20)
    floor = models.PositiveIntegerField(default=1)
    room_type = models.CharField(max_length=20, choices=ROOM_TYPE_CHOICES, default='double')
    capacity = models.PositiveIntegerField(default=2, help_text="Total bed capacity in this room")
    total_beds = models.PositiveIntegerField(default=2)
    price_per_month = models.DecimalField(max_digits=10, decimal_places=2)
    price_per_day = models.DecimalField(max_digits=10, decimal_places=2, default=500.00)
    is_ac = models.BooleanField(default=False)
    has_attached_washroom = models.BooleanField(default=True)
    has_balcony = models.BooleanField(default=False)
    description = models.TextField(blank=True)
    image_url = models.CharField(
        max_length=500,
        blank=True,
        default='https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80'
    )
    is_available = models.BooleanField(default=True)

    class Meta:
        unique_together = ('hostel', 'room_number')
        ordering = ['hostel', 'room_number']

    def __str__(self):
        return f"{self.hostel.name} - Room {self.room_number} ({self.get_room_type_display()})"

    def save(self, *args, **kwargs):
        if not self.total_beds:
            self.total_beds = self.capacity
        super().save(*args, **kwargs)

    def get_active_bookings(self, check_in=None, check_out=None):
        """Returns bookings that overlap with the provided date range."""
        if not check_in:
            check_in = date.today()
        if not check_out:
            check_out = check_in

        # Overlap condition:
        # A booking overlaps if booking.check_in < check_out AND booking.check_out > check_in
        return self.bookings.filter(
            status__in=['confirmed', 'pending']
        ).filter(
            check_in__lt=check_out,
            check_out__gt=check_in
        )

    def get_available_beds(self, check_in=None, check_out=None):
        """
        Calculates remaining available beds in this room for a date window.
        Prevents double-booking!
        """
        if not self.is_available:
            return 0
        overlapping = self.get_active_bookings(check_in, check_out).count()
        remaining = self.capacity - overlapping
        return max(0, remaining)

    def is_available_for_dates(self, check_in, check_out):
        """Checks if at least one bed is available between check_in and check_out."""
        return self.get_available_beds(check_in, check_out) > 0


class Booking(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending Approval'),
        ('confirmed', 'Confirmed'),
        ('cancelled', 'Cancelled'),
        ('completed', 'Completed'),
    )

    booking_id = models.CharField(max_length=30, unique=True, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bookings')
    room = models.ForeignKey(Room, on_delete=models.CASCADE, related_name='bookings')
    check_in = models.DateField()
    check_out = models.DateField()
    duration_days = models.PositiveIntegerField(default=30)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    advance_amount = models.DecimalField(max_digits=10, decimal_places=2)
    remaining_amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='confirmed')
    guest_name = models.CharField(max_length=150)
    guest_phone = models.CharField(max_length=20)
    guest_email = models.EmailField()
    emergency_contact = models.CharField(max_length=20, blank=True)
    special_requests = models.TextField(blank=True)
    cancellation_reason = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def save(self, *args, **kwargs):
        if not self.booking_id:
            # Generate unique human-readable booking ID like HST-2026-A1B2C
            random_code = uuid.uuid4().hex[:6].upper()
            year = date.today().year
            self.booking_id = f"HST-{year}-{random_code}"
            while Booking.objects.filter(booking_id=self.booking_id).exists():
                random_code = uuid.uuid4().hex[:6].upper()
                self.booking_id = f"HST-{year}-{random_code}"

        if not self.duration_days and self.check_in and self.check_out:
            delta = (self.check_out - self.check_in).days
            self.duration_days = max(1, delta)

        if self.remaining_amount is None:
            self.remaining_amount = max(0, self.total_amount - self.advance_amount)

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.booking_id} - {self.guest_name} ({self.room.hostel.name})"

    @property
    def is_paid(self):
        successful_payments = self.payments.filter(status='success').aggregate(total=Sum('amount'))['total'] or 0
        return successful_payments >= self.total_amount

    @property
    def total_paid(self):
        return self.payments.filter(status='success').aggregate(total=Sum('amount'))['total'] or 0


class Payment(models.Model):
    PAYMENT_METHOD_CHOICES = (
        ('upi', 'UPI / QR Code'),
        ('card', 'Credit / Debit Card'),
        ('netbanking', 'Net Banking'),
        ('cash', 'Cash at Desk / Pay at Check-in'),
    )
    PAYMENT_TYPE_CHOICES = (
        ('advance', 'Advance Booking Deposit'),
        ('full', 'Full Booking Payment'),
        ('remaining', 'Remaining Balance Payment'),
    )
    STATUS_CHOICES = (
        ('success', 'Successful'),
        ('pending', 'Pending Verification'),
        ('failed', 'Failed'),
    )

    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name='payments')
    transaction_id = models.CharField(max_length=60, unique=True)
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES, default='upi')
    payment_type = models.CharField(max_length=20, choices=PAYMENT_TYPE_CHOICES, default='advance')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='success')
    payment_date = models.DateTimeField(auto_now_add=True)
    card_last4 = models.CharField(max_length=4, blank=True)
    upi_id = models.CharField(max_length=100, blank=True)
    bank_name = models.CharField(max_length=100, blank=True)
    remarks = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ['-payment_date']

    def save(self, *args, **kwargs):
        if not self.transaction_id:
            random_id = uuid.uuid4().hex[:10].upper()
            self.transaction_id = f"PAY-{random_id}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.transaction_id} - {self.booking.booking_id} (₹{self.amount})"


class Review(models.Model):
    RATING_CHOICES = (
        (5, '5 Stars - Excellent'),
        (4, '4 Stars - Very Good'),
        (3, '3 Stars - Average'),
        (2, '2 Stars - Poor'),
        (1, '1 Star - Terrible'),
    )

    hostel = models.ForeignKey(Hostel, on_delete=models.CASCADE, related_name='reviews')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reviews')
    rating = models.PositiveIntegerField(choices=RATING_CHOICES, default=5)
    title = models.CharField(max_length=150, blank=True)
    comment = models.TextField()
    is_approved = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        unique_together = ('hostel', 'user')

    def __str__(self):
        return f"{self.user.username}'s review for {self.hostel.name} ({self.rating}★)"
