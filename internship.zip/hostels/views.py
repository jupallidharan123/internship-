import math
from datetime import datetime, date, timedelta
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.db.models import Q, Count, Sum, Avg
from django.views.decorators.http import require_POST
from django.core.paginator import Paginator

from .models import UserProfile, Facility, Hostel, HostelImage, Room, Booking, Payment, Review
from .forms import (
    UserRegisterForm, UserLoginForm, UserProfileUpdateForm,
    PasswordResetRequestForm, PasswordResetConfirmForm,
    BookingForm, ReviewForm, HostelForm, RoomForm
)


# ==============================================================================
# Helper functions
# ==============================================================================

def is_admin_or_staff(user):
    return user.is_authenticated and (user.is_staff or user.is_superuser or (hasattr(user, 'profile') and user.profile.user_type == 'admin'))


# ==============================================================================
# Public Views
# ==============================================================================

def home_view(request):
    """Modern Homepage with Hero Search, Statistics, and Featured Hostels."""
    featured_hostels = Hostel.objects.filter(is_active=True).prefetch_related('facilities', 'rooms', 'reviews')[:6]
    facilities = Facility.objects.all()[:8]
    
    # Calculate live platform statistics
    total_hostels = Hostel.objects.filter(is_active=True).count()
    total_rooms = Room.objects.filter(is_available=True).count()
    total_bookings = Booking.objects.filter(status='confirmed').count()
    cities = Hostel.objects.filter(is_active=True).values_list('city', flat=True).distinct()
    
    context = {
        'featured_hostels': featured_hostels,
        'facilities': facilities,
        'total_hostels': total_hostels,
        'total_rooms': total_rooms,
        'total_bookings': total_bookings + 120, # baseline count for demo realism
        'cities_count': len(cities),
        'cities': cities,
    }
    return render(request, 'hostels/home.html', context)


def hostel_list_view(request):
    """
    Search and Filter Hostels by:
    - City
    - Location / Name / Landmark
    - Hostel Type (Boys, Girls, Co-living)
    - Budget Range (Min & Max Price)
    - Room Type
    - Facilities
    """
    hostels_qs = Hostel.objects.filter(is_active=True).prefetch_related('facilities', 'rooms', 'reviews')
    
    # Query parameters
    q = request.GET.get('q', '').strip()
    city = request.GET.get('city', '').strip()
    hostel_type = request.GET.get('type', '').strip()
    min_price = request.GET.get('min_price', '').strip()
    max_price = request.GET.get('max_price', '').strip()
    room_type = request.GET.get('room_type', '').strip()
    facility_ids = request.GET.getlist('facility')
    sort_by = request.GET.get('sort', 'popular')

    if q:
        hostels_qs = hostels_qs.filter(
            Q(name__icontains=q) |
            Q(address__icontains=q) |
            Q(city__icontains=q) |
            Q(landmark__icontains=q) |
            Q(description__icontains=q)
        )

    if city:
        hostels_qs = hostels_qs.filter(city__iexact=city)

    if hostel_type in ['boys', 'girls', 'coliving']:
        hostels_qs = hostels_qs.filter(hostel_type=hostel_type)

    if room_type:
        hostels_qs = hostels_qs.filter(rooms__room_type=room_type, rooms__is_available=True).distinct()

    if facility_ids:
        for f_id in facility_ids:
            if f_id.isdigit():
                hostels_qs = hostels_qs.filter(facilities__id=int(f_id))

    if min_price and min_price.isdigit():
        hostels_qs = hostels_qs.filter(rooms__price_per_month__gte=int(min_price)).distinct()

    if max_price and max_price.isdigit():
        hostels_qs = hostels_qs.filter(rooms__price_per_month__lte=int(max_price)).distinct()

    # Sorting
    if sort_by == 'price_low':
        hostels_qs = hostels_qs.order_by('rooms__price_per_month').distinct()
    elif sort_by == 'price_high':
        hostels_qs = hostels_qs.order_by('-rooms__price_per_month').distinct()
    elif sort_by == 'newest':
        hostels_qs = hostels_qs.order_by('-created_at')
    else:
        # Default popular
        hostels_qs = hostels_qs.order_by('-created_at')

    # Pagination
    paginator = Paginator(hostels_qs, 9)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    all_facilities = Facility.objects.all()
    all_cities = Hostel.objects.filter(is_active=True).values_list('city', flat=True).distinct().order_by('city')

    context = {
        'page_obj': page_obj,
        'all_facilities': all_facilities,
        'all_cities': all_cities,
        'selected_q': q,
        'selected_city': city,
        'selected_type': hostel_type,
        'selected_min_price': min_price,
        'selected_max_price': max_price,
        'selected_room_type': room_type,
        'selected_facilities': [int(f) for f in facility_ids if f.isdigit()],
        'selected_sort': sort_by,
        'total_results': paginator.count,
    }
    return render(request, 'hostels/hostel_list.html', context)


def hostel_detail_view(request, slug):
    """Detailed view for a specific hostel with rooms, facilities, gallery, and reviews."""
    hostel = get_object_or_404(
        Hostel.objects.prefetch_related('facilities', 'rooms', 'gallery_images', 'reviews__user'),
        slug=slug,
        is_active=True
    )
    
    # Calculate bed availability for each room for today's date
    today = date.today()
    rooms_data = []
    for r in hostel.rooms.filter(is_available=True):
        avail_beds = r.get_available_beds(today, today + timedelta(days=30))
        rooms_data.append({
            'room': r,
            'available_beds': avail_beds,
            'is_sold_out': avail_beds <= 0,
        })

    reviews = hostel.reviews.filter(is_approved=True)
    user_review = None
    if request.user.is_authenticated:
        user_review = hostel.reviews.filter(user=request.user).first()

    similar_hostels = Hostel.objects.filter(city=hostel.city, is_active=True).exclude(pk=hostel.pk)[:3]
    review_form = ReviewForm()

    context = {
        'hostel': hostel,
        'rooms_data': rooms_data,
        'reviews': reviews,
        'user_review': user_review,
        'review_form': review_form,
        'similar_hostels': similar_hostels,
        'today_str': today.strftime('%Y-%m-%d'),
        'next_month_str': (today + timedelta(days=30)).strftime('%Y-%m-%d'),
    }
    return render(request, 'hostels/hostel_detail.html', context)


def about_view(request):
    """About us page."""
    return render(request, 'hostels/about.html')


def contact_view(request):
    """Contact page with message feedback."""
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message_text = request.POST.get('message')
        messages.success(request, f"Thank you, {name}! Your message regarding '{subject}' has been received. Our team will contact you shortly at {email}.")
        return redirect('contact')
    return render(request, 'hostels/contact.html')


# ==============================================================================
# Authentication Views
# ==============================================================================

def register_view(request):
    """User Registration with password hashing and UserProfile creation."""
    if request.user.is_authenticated:
        return redirect('user_dashboard')

    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()

            # Create UserProfile
            phone_number = form.cleaned_data.get('phone_number')
            user_type = form.cleaned_data.get('user_type', 'student')
            UserProfile.objects.create(
                user=user,
                phone_number=phone_number,
                user_type=user_type,
            )

            # Auto login after registration
            login(request, user)
            messages.success(request, f"Welcome to StayEase, {user.first_name}! Your account has been created successfully.")
            return redirect('user_dashboard')
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = UserRegisterForm()

    return render(request, 'hostels/auth/register.html', {'form': form})


def login_view(request):
    """User Login with username or email support."""
    if request.user.is_authenticated:
        if is_admin_or_staff(request.user):
            return redirect('admin_dashboard')
        return redirect('user_dashboard')

    if request.method == 'POST':
        form = UserLoginForm(request.POST)
        if form.is_valid():
            username_or_email = form.cleaned_data['username'].strip()
            password = form.cleaned_data['password']

            # Check if input is email
            username = username_or_email
            if '@' in username_or_email:
                user_obj = User.objects.filter(email__iexact=username_or_email).first()
                if user_obj:
                    username = user_obj.username

            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f"Welcome back, {user.first_name or user.username}!")
                
                next_url = request.GET.get('next')
                if next_url:
                    return redirect(next_url)
                
                if is_admin_or_staff(user):
                    return redirect('admin_dashboard')
                return redirect('user_dashboard')
            else:
                messages.error(request, "Invalid username/email or password.")
    else:
        form = UserLoginForm()

    return render(request, 'hostels/auth/login.html', {'form': form})


def logout_view(request):
    """User Logout."""
    logout(request)
    messages.info(request, "You have been logged out successfully.")
    return redirect('home')


def forgot_password_view(request):
    """Interactive demo forgot password with instant reset token simulation."""
    if request.method == 'POST':
        form = PasswordResetRequestForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            user = User.objects.get(email=email)
            # Store user ID in session for demonstration password reset
            request.session['reset_user_id'] = user.id
            messages.success(request, f"Password reset instructions have been generated for {email}.")
            return redirect('reset_password')
    else:
        form = PasswordResetRequestForm()
    return render(request, 'hostels/auth/forgot_password.html', {'form': form})


def reset_password_view(request):
    """Reset password page after requesting reset."""
    user_id = request.session.get('reset_user_id')
    if not user_id:
        messages.warning(request, "Please enter your email to request a password reset first.")
        return redirect('forgot_password')

    user = get_object_or_404(User, pk=user_id)
    if request.method == 'POST':
        form = PasswordResetConfirmForm(request.POST)
        if form.is_valid():
            new_password = form.cleaned_data['new_password']
            user.set_password(new_password)
            user.save()
            # Clear reset session
            del request.session['reset_user_id']
            messages.success(request, "Your password has been reset successfully! You can now log in.")
            return redirect('login')
    else:
        form = PasswordResetConfirmForm()

    return render(request, 'hostels/auth/reset_password.html', {'form': form, 'user_obj': user})


# ==============================================================================
# Availability & Booking Engine (with Double-Booking Prevention)
# ==============================================================================

def check_availability_api(request):
    """
    AJAX endpoint:
    Checks live bed availability for a specific room and calculates cost based on check_in and check_out.
    """
    room_id = request.GET.get('room_id')
    check_in_str = request.GET.get('check_in')
    check_out_str = request.GET.get('check_out')

    if not all([room_id, check_in_str, check_out_str]):
        return JsonResponse({'success': False, 'error': 'Missing parameters.'})

    try:
        room = Room.objects.get(pk=room_id)
        check_in = datetime.strptime(check_in_str, '%Y-%m-%d').date()
        check_out = datetime.strptime(check_out_str, '%Y-%m-%d').date()

        if check_out <= check_in:
            return JsonResponse({'success': False, 'error': 'Check-out must be after check-in date.'})

        # Calculate duration
        days = (check_out - check_in).days
        months = max(1, math.ceil(days / 30.0))

        # Check available beds for this window (Double-Booking Prevention!)
        available_beds = room.get_available_beds(check_in, check_out)

        # Pricing calculation
        # If duration is 30 days or more, use monthly rate proportional to months, else daily rate
        if days >= 25:
            total_amount = float(room.price_per_month * months)
        else:
            total_amount = float(room.price_per_day * days)

        advance_amount = round(total_amount * 0.25, 2)
        remaining_amount = round(total_amount - advance_amount, 2)

        return JsonResponse({
            'success': True,
            'available_beds': available_beds,
            'is_available': available_beds > 0,
            'days': days,
            'months': months,
            'total_amount': total_amount,
            'advance_amount': advance_amount,
            'remaining_amount': remaining_amount,
            'room_type': room.get_room_type_display(),
            'room_number': room.room_number,
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
def book_room_view(request, room_id):
    """
    Step 1 of Booking:
    User selects dates, provides guest details, verifies total price and advance amount.
    Applies double-booking prevention check before creating booking.
    """
    room = get_object_or_404(Room.objects.select_related('hostel'), pk=room_id, is_available=True)
    profile = getattr(request.user, 'profile', None)

    # Initial dates from query or defaults
    initial_check_in = request.GET.get('check_in') or date.today().strftime('%Y-%m-%d')
    initial_check_out = request.GET.get('check_out') or (date.today() + timedelta(days=30)).strftime('%Y-%m-%d')

    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            check_in = form.cleaned_data['check_in']
            check_out = form.cleaned_data['check_out']
            payment_choice = form.cleaned_data['payment_choice']

            # CRITICAL DOUBLE-BOOKING CHECK
            available_beds = room.get_available_beds(check_in, check_out)
            if available_beds <= 0:
                messages.error(
                    request,
                    f"Sorry! Room {room.room_number} is completely booked between {check_in} and {check_out}. Please choose another room or different dates."
                )
                return render(request, 'hostels/booking/book_room.html', {'room': room, 'form': form})

            # Calculate duration and pricing
            days = (check_out - check_in).days
            months = max(1, math.ceil(days / 30.0))
            if days >= 25:
                total_amount = room.price_per_month * months
            else:
                total_amount = room.price_per_day * days

            if payment_choice == 'full':
                advance_amount = total_amount
                remaining_amount = 0
            else:
                advance_amount = round(total_amount * 0.25, 2)
                remaining_amount = total_amount - advance_amount

            # Create booking in 'pending' status until payment is simulated
            booking = form.save(commit=False)
            booking.user = request.user
            booking.room = room
            booking.duration_days = days
            booking.total_amount = total_amount
            booking.advance_amount = advance_amount
            booking.remaining_amount = remaining_amount
            booking.status = 'pending'
            booking.save()

            messages.info(request, "Booking details saved! Please complete your demo payment to confirm your reservation.")
            return redirect('payment_gateway', booking_id=booking.booking_id)
    else:
        # Prepopulate with profile details
        initial_data = {
            'check_in': initial_check_in,
            'check_out': initial_check_out,
            'guest_name': f"{request.user.first_name} {request.user.last_name}".strip() or request.user.username,
            'guest_email': request.user.email,
            'guest_phone': profile.phone_number if profile else '',
            'emergency_contact': profile.emergency_contact if profile else '',
        }
        form = BookingForm(initial=initial_data)

    context = {
        'room': room,
        'form': form,
    }
    return render(request, 'hostels/booking/book_room.html', context)


@login_required
def payment_gateway_view(request, booking_id):
    """
    Step 2: Simulated Demo Payment Gateway.
    Allows testing various payment methods (UPI, Card, Net Banking, Cash at Desk).
    Confirms booking upon success and generates transaction receipt.
    """
    booking = get_object_or_404(Booking.objects.select_related('room__hostel', 'user'), booking_id=booking_id)

    # Security check: User must own the booking or be admin
    if booking.user != request.user and not is_admin_or_staff(request.user):
        messages.error(request, "Unauthorized access to this booking.")
        return redirect('user_dashboard')

    if booking.status == 'confirmed' and booking.payments.filter(status='success').exists():
        messages.info(request, "This booking has already been paid and confirmed.")
        return redirect('booking_receipt', booking_id=booking.booking_id)

    if request.method == 'POST':
        payment_method = request.POST.get('payment_method', 'upi')
        payment_status_choice = request.POST.get('simulation_status', 'success')
        card_number = request.POST.get('card_number', '').replace(' ', '')
        upi_id = request.POST.get('upi_id', '')
        bank_name = request.POST.get('bank_name', '')
        
        pay_amount = booking.advance_amount if booking.advance_amount > 0 else booking.total_amount

        card_last4 = card_number[-4:] if len(card_number) >= 4 else '4242'
        remarks = f"Demo Payment via {payment_method.upper()}"

        if payment_status_choice == 'failed':
            # Create failed payment record
            Payment.objects.create(
                booking=booking,
                payment_method=payment_method,
                payment_type='advance' if booking.remaining_amount > 0 else 'full',
                amount=pay_amount,
                status='failed',
                card_last4=card_last4,
                upi_id=upi_id,
                bank_name=bank_name,
                remarks="Simulated Transaction Declined by Issuer"
            )
            messages.error(request, "Transaction Failed: Simulated bank card declined or timeout. Please try again.")
            return redirect('payment_gateway', booking_id=booking.booking_id)

        # Successful payment simulation
        payment = Payment.objects.create(
            booking=booking,
            payment_method=payment_method,
            payment_type='advance' if booking.remaining_amount > 0 else 'full',
            amount=pay_amount,
            status='success',
            card_last4=card_last4,
            upi_id=upi_id,
            bank_name=bank_name,
            remarks=remarks
        )

        # Update booking status to Confirmed
        booking.status = 'confirmed'
        booking.save()

        messages.success(
            request,
            f"Payment of ₹{pay_amount} successful! Your reservation is CONFIRMED with Booking ID {booking.booking_id}."
        )
        return redirect('booking_receipt', booking_id=booking.booking_id)

    context = {
        'booking': booking,
        'payable_amount': booking.advance_amount if booking.advance_amount > 0 else booking.total_amount,
    }
    return render(request, 'hostels/booking/payment_gateway.html', context)


@login_required
def booking_receipt_view(request, booking_id):
    """Generates a clean, printable & downloadable Booking Confirmation Receipt."""
    booking = get_object_or_404(
        Booking.objects.select_related('room__hostel', 'user').prefetch_related('payments'),
        booking_id=booking_id
    )

    if booking.user != request.user and not is_admin_or_staff(request.user):
        messages.error(request, "You are not authorized to view this receipt.")
        return redirect('user_dashboard')

    latest_payment = booking.payments.filter(status='success').first()

    context = {
        'booking': booking,
        'payment': latest_payment,
    }
    return render(request, 'hostels/booking/booking_receipt.html', context)


@login_required
def cancel_booking_view(request, booking_id):
    """Allows user to cancel a reservation, with reason."""
    booking = get_object_or_404(Booking, booking_id=booking_id, user=request.user)

    if booking.status == 'cancelled':
        messages.warning(request, "This booking has already been cancelled.")
        return redirect('user_dashboard')

    if request.method == 'POST':
        reason = request.POST.get('cancellation_reason', 'Cancelled by guest')
        booking.status = 'cancelled'
        booking.cancellation_reason = reason
        booking.save()
        messages.success(request, f"Booking {booking.booking_id} has been cancelled successfully.")
        return redirect('user_dashboard')

    return render(request, 'hostels/booking/cancel_booking.html', {'booking': booking})


# ==============================================================================
# User Dashboard Views
# ==============================================================================

@login_required
def user_dashboard_view(request):
    """
    User Dashboard:
    - Current, upcoming, and previous bookings
    - Booking status tracking
    - Profile update shortcut
    - Quick actions to review completed stays
    """
    user_bookings = Booking.objects.filter(user=request.user).select_related('room__hostel').order_by('-created_at')
    
    total_bookings = user_bookings.count()
    active_bookings = user_bookings.filter(status__in=['confirmed', 'pending']).count()
    completed_bookings = user_bookings.filter(status='completed').count()
    total_spent = user_bookings.filter(status='confirmed').aggregate(total=Sum('total_amount'))['total'] or 0

    upcoming_stay = user_bookings.filter(status='confirmed', check_out__gte=date.today()).first()
    recent_bookings = user_bookings[:5]

    context = {
        'total_bookings': total_bookings,
        'active_bookings': active_bookings,
        'completed_bookings': completed_bookings,
        'total_spent': total_spent,
        'upcoming_stay': upcoming_stay,
        'recent_bookings': recent_bookings,
    }
    return render(request, 'hostels/user/dashboard.html', context)


@login_required
def my_bookings_view(request):
    """Full list of bookings with status filter."""
    status_filter = request.GET.get('status', 'all')
    bookings_qs = Booking.objects.filter(user=request.user).select_related('room__hostel').prefetch_related('payments')

    if status_filter in ['confirmed', 'pending', 'cancelled', 'completed']:
        bookings_qs = bookings_qs.filter(status=status_filter)

    bookings_qs = bookings_qs.order_by('-created_at')

    context = {
        'bookings': bookings_qs,
        'selected_status': status_filter,
    }
    return render(request, 'hostels/user/my_bookings.html', context)


@login_required
def profile_view(request):
    """Profile View and Update."""
    profile, _ = UserProfile.objects.get_or_create(user=request.user)

    if request.method == 'POST':
        form = UserProfileUpdateForm(request.POST, instance=profile)
        if form.is_valid():
            # Update User model fields
            request.user.first_name = form.cleaned_data['first_name']
            request.user.last_name = form.cleaned_data['last_name']
            request.user.email = form.cleaned_data['email']
            request.user.save()

            form.save()
            messages.success(request, "Your profile has been updated successfully!")
            return redirect('user_profile')
    else:
        initial = {
            'first_name': request.user.first_name,
            'last_name': request.user.last_name,
            'email': request.user.email,
        }
        form = UserProfileUpdateForm(instance=profile, initial=initial)

    return render(request, 'hostels/user/profile.html', {'form': form, 'profile': profile})


@login_required
@require_POST
def submit_review_view(request, hostel_id):
    """Submit rating and review for a hostel after stay."""
    hostel = get_object_or_404(Hostel, pk=hostel_id)
    
    # Check if user already reviewed
    existing = Review.objects.filter(hostel=hostel, user=request.user).first()
    if existing:
        form = ReviewForm(request.POST, instance=existing)
    else:
        form = ReviewForm(request.POST)

    if form.is_valid():
        review = form.save(commit=False)
        review.hostel = hostel
        review.user = request.user
        review.is_approved = True
        review.save()
        messages.success(request, "Thank you! Your review and rating have been posted.")
    else:
        messages.error(request, "Could not submit review. Please ensure rating and comment are provided.")

    return redirect('hostel_detail', slug=hostel.slug)


# ==============================================================================
# Admin Module
# ==============================================================================

@login_required
@user_passes_test(is_admin_or_staff)
def admin_dashboard_view(request):
    """
    Hostel Management Admin Dashboard:
    - Overview KPIs: Total Hostels, Available Beds, Total Bookings, Revenue, Pending Requests
    - Quick Booking Status updates (Approve, Reject, Complete)
    - Occupancy summary
    """
    total_hostels = Hostel.objects.count()
    total_rooms = Room.objects.count()
    total_beds = Room.objects.aggregate(total=Sum('total_beds'))['total'] or 0
    total_bookings = Booking.objects.count()
    pending_bookings = Booking.objects.filter(status='pending').count()
    confirmed_bookings = Booking.objects.filter(status='confirmed').count()
    total_revenue = Payment.objects.filter(status='success').aggregate(total=Sum('amount'))['total'] or 0
    total_users = User.objects.filter(is_staff=False).count()

    recent_bookings = Booking.objects.select_related('room__hostel', 'user').order_by('-created_at')[:8]
    hostels_list = Hostel.objects.annotate(rooms_count=Count('rooms')).order_by('-created_at')[:5]

    context = {
        'total_hostels': total_hostels,
        'total_rooms': total_rooms,
        'total_beds': total_beds,
        'total_bookings': total_bookings,
        'pending_bookings': pending_bookings,
        'confirmed_bookings': confirmed_bookings,
        'total_revenue': total_revenue,
        'total_users': total_users,
        'recent_bookings': recent_bookings,
        'hostels_list': hostels_list,
    }
    return render(request, 'hostels/admin/dashboard.html', context)


@login_required
@user_passes_test(is_admin_or_staff)
def admin_hostel_list_view(request):
    """Admin: List, search, and manage all hostels."""
    hostels = Hostel.objects.annotate(rooms_count=Count('rooms')).order_by('-created_at')
    return render(request, 'hostels/admin/hostel_list.html', {'hostels': hostels})


@login_required
@user_passes_test(is_admin_or_staff)
def admin_hostel_create_view(request):
    """Admin: Add a new hostel."""
    if request.method == 'POST':
        form = HostelForm(request.POST)
        if form.is_valid():
            hostel = form.save()
            messages.success(request, f"Hostel '{hostel.name}' added successfully!")
            return redirect('admin_hostel_list')
    else:
        form = HostelForm()
    return render(request, 'hostels/admin/hostel_form.html', {'form': form, 'title': 'Add New Hostel'})


@login_required
@user_passes_test(is_admin_or_staff)
def admin_hostel_edit_view(request, pk):
    """Admin: Edit an existing hostel."""
    hostel = get_object_or_404(Hostel, pk=pk)
    if request.method == 'POST':
        form = HostelForm(request.POST, instance=hostel)
        if form.is_valid():
            form.save()
            messages.success(request, f"Hostel '{hostel.name}' updated successfully!")
            return redirect('admin_hostel_list')
    else:
        form = HostelForm(instance=hostel)
    return render(request, 'hostels/admin/hostel_form.html', {'form': form, 'hostel': hostel, 'title': f'Edit Hostel: {hostel.name}'})


@login_required
@user_passes_test(is_admin_or_staff)
def admin_hostel_delete_view(request, pk):
    """Admin: Delete a hostel."""
    hostel = get_object_or_404(Hostel, pk=pk)
    if request.method == 'POST':
        name = hostel.name
        hostel.delete()
        messages.success(request, f"Hostel '{name}' and associated rooms deleted.")
        return redirect('admin_hostel_list')
    return render(request, 'hostels/admin/confirm_delete.html', {'object': hostel, 'type': 'Hostel'})


@login_required
@user_passes_test(is_admin_or_staff)
def admin_room_list_view(request):
    """Admin: Manage rooms across all hostels."""
    hostel_id = request.GET.get('hostel')
    rooms = Room.objects.select_related('hostel').order_by('hostel__name', 'room_number')
    
    if hostel_id and hostel_id.isdigit():
        rooms = rooms.filter(hostel_id=int(hostel_id))

    hostels = Hostel.objects.all().order_by('name')
    return render(request, 'hostels/admin/room_list.html', {'rooms': rooms, 'hostels': hostels, 'selected_hostel': hostel_id})


@login_required
@user_passes_test(is_admin_or_staff)
def admin_room_create_view(request):
    """Admin: Add a new room."""
    if request.method == 'POST':
        form = RoomForm(request.POST)
        if form.is_valid():
            room = form.save()
            messages.success(request, f"Room {room.room_number} in '{room.hostel.name}' added successfully!")
            return redirect('admin_room_list')
    else:
        form = RoomForm()
    return render(request, 'hostels/admin/room_form.html', {'form': form, 'title': 'Add New Room'})


@login_required
@user_passes_test(is_admin_or_staff)
def admin_room_edit_view(request, pk):
    """Admin: Edit room details."""
    room = get_object_or_404(Room, pk=pk)
    if request.method == 'POST':
        form = RoomForm(request.POST, instance=room)
        if form.is_valid():
            form.save()
            messages.success(request, f"Room {room.room_number} updated successfully!")
            return redirect('admin_room_list')
    else:
        form = RoomForm(instance=room)
    return render(request, 'hostels/admin/room_form.html', {'form': form, 'room': room, 'title': f'Edit Room: {room.room_number}'})


@login_required
@user_passes_test(is_admin_or_staff)
def admin_room_delete_view(request, pk):
    """Admin: Delete a room."""
    room = get_object_or_404(Room, pk=pk)
    if request.method == 'POST':
        room.delete()
        messages.success(request, f"Room {room.room_number} deleted successfully.")
        return redirect('admin_room_list')
    return render(request, 'hostels/admin/confirm_delete.html', {'object': room, 'type': 'Room'})


@login_required
@user_passes_test(is_admin_or_staff)
def admin_booking_list_view(request):
    """Admin: View all customer bookings and filter by status."""
    status_filter = request.GET.get('status', 'all')
    bookings = Booking.objects.select_related('room__hostel', 'user').prefetch_related('payments').order_by('-created_at')

    if status_filter in ['pending', 'confirmed', 'cancelled', 'completed']:
        bookings = bookings.filter(status=status_filter)

    return render(request, 'hostels/admin/booking_list.html', {'bookings': bookings, 'selected_status': status_filter})


@login_required
@user_passes_test(is_admin_or_staff)
def admin_booking_status_update(request, booking_id):
    """Admin: Approve, reject, cancel, or complete booking."""
    booking = get_object_or_404(Booking, booking_id=booking_id)
    if request.method == 'POST':
        new_status = request.POST.get('status')
        if new_status in ['pending', 'confirmed', 'cancelled', 'completed']:
            booking.status = new_status
            booking.save()
            messages.success(request, f"Booking {booking.booking_id} status updated to '{booking.get_status_display()}'.")
    return redirect(request.META.get('HTTP_REFERER', 'admin_booking_list'))


@login_required
@user_passes_test(is_admin_or_staff)
def admin_payment_list_view(request):
    """Admin: Track all payments and transactions."""
    payments = Payment.objects.select_related('booking__user', 'booking__room__hostel').order_by('-payment_date')
    total_collected = payments.filter(status='success').aggregate(total=Sum('amount'))['total'] or 0
    return render(request, 'hostels/admin/payment_list.html', {'payments': payments, 'total_collected': total_collected})


@login_required
@user_passes_test(is_admin_or_staff)
def admin_user_list_view(request):
    """Admin: View registered customers and their bookings count."""
    users = User.objects.filter(is_staff=False).select_related('profile').annotate(
        booking_count=Count('bookings')
    ).order_by('-date_joined')
    return render(request, 'hostels/admin/user_list.html', {'users': users})


@login_required
@user_passes_test(is_admin_or_staff)
def admin_reports_view(request):
    """Admin: Occupancy, Revenue, and Hostel Performance Reports."""
    hostel_stats = []
    for h in Hostel.objects.filter(is_active=True):
        rooms = h.rooms.all()
        total_beds = sum(r.total_beds for r in rooms)
        avail_beds = sum(r.get_available_beds() for r in rooms)
        occupied_beds = max(0, total_beds - avail_beds)
        occupancy_rate = round((occupied_beds / total_beds * 100), 1) if total_beds > 0 else 0
        revenue = Payment.objects.filter(booking__room__hostel=h, status='success').aggregate(total=Sum('amount'))['total'] or 0

        hostel_stats.append({
            'hostel': h,
            'total_beds': total_beds,
            'avail_beds': avail_beds,
            'occupied_beds': occupied_beds,
            'occupancy_rate': occupancy_rate,
            'revenue': revenue,
        })

    total_revenue = Payment.objects.filter(status='success').aggregate(total=Sum('amount'))['total'] or 0
    recent_payments = Payment.objects.filter(status='success').select_related('booking__room__hostel').order_by('-payment_date')[:10]

    context = {
        'hostel_stats': hostel_stats,
        'total_revenue': total_revenue,
        'recent_payments': recent_payments,
    }
    return render(request, 'hostels/admin/reports.html', context)
