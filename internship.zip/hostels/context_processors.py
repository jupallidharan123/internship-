from .models import Hostel

def site_context(request):
    """Global context variables available to all templates."""
    try:
        cities = Hostel.objects.filter(is_active=True).values_list('city', flat=True).distinct().order_by('city')
    except Exception:
        cities = []
    
    return {
        'site_name': 'StayEase Hostel Hub',
        'available_cities': cities,
    }

