from django.urls import path
from . import views

urlpatterns = [
    # Public & Discovery
    path('', views.home_view, name='home'),
    path('hostels/', views.hostel_list_view, name='hostel_list'),
    path('hostel/<slug:slug>/', views.hostel_detail_view, name='hostel_detail'),
    path('about/', views.about_view, name='about'),
    path('contact/', views.contact_view, name='contact'),

    # Authentication
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('forgot-password/', views.forgot_password_view, name='forgot_password'),
    path('reset-password/', views.reset_password_view, name='reset_password'),

    # Booking & Payment
    path('api/check-availability/', views.check_availability_api, name='check_availability_api'),
    path('book/<int:room_id>/', views.book_room_view, name='book_room'),
    path('payment/<str:booking_id>/', views.payment_gateway_view, name='payment_gateway'),
    path('receipt/<str:booking_id>/', views.booking_receipt_view, name='booking_receipt'),
    path('cancel-booking/<str:booking_id>/', views.cancel_booking_view, name='cancel_booking'),

    # User Dashboard
    path('dashboard/', views.user_dashboard_view, name='user_dashboard'),
    path('my-bookings/', views.my_bookings_view, name='my_bookings'),
    path('profile/', views.profile_view, name='user_profile'),
    path('review/<int:hostel_id>/', views.submit_review_view, name='submit_review'),

    # Admin Management Module
    path('admin-dashboard/', views.admin_dashboard_view, name='admin_dashboard'),
    path('admin-dashboard/hostels/', views.admin_hostel_list_view, name='admin_hostel_list'),
    path('admin-dashboard/hostels/add/', views.admin_hostel_create_view, name='admin_hostel_create'),
    path('admin-dashboard/hostels/edit/<int:pk>/', views.admin_hostel_edit_view, name='admin_hostel_edit'),
    path('admin-dashboard/hostels/delete/<int:pk>/', views.admin_hostel_delete_view, name='admin_hostel_delete'),
    
    path('admin-dashboard/rooms/', views.admin_room_list_view, name='admin_room_list'),
    path('admin-dashboard/rooms/add/', views.admin_room_create_view, name='admin_room_create'),
    path('admin-dashboard/rooms/edit/<int:pk>/', views.admin_room_edit_view, name='admin_room_edit'),
    path('admin-dashboard/rooms/delete/<int:pk>/', views.admin_room_delete_view, name='admin_room_delete'),
    
    path('admin-dashboard/bookings/', views.admin_booking_list_view, name='admin_booking_list'),
    path('admin-dashboard/bookings/update-status/<str:booking_id>/', views.admin_booking_status_update, name='admin_booking_status_update'),
    path('admin-dashboard/payments/', views.admin_payment_list_view, name='admin_payment_list'),
    path('admin-dashboard/users/', views.admin_user_list_view, name='admin_user_list'),
    path('admin-dashboard/reports/', views.admin_reports_view, name='admin_reports'),
]

